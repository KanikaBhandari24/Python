# name=input("Enter your name: ")
# le=len(name)
# print(le)

#OR

print(len(input("Enter your name: ")))